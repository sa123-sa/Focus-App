package com.deepfocus.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.deepfocus.app.data.local.dao.StudySessionDao
import com.deepfocus.app.data.local.entity.StudySessionEntity
import com.deepfocus.app.service.StudyNotificationListener
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

sealed class PomodoroState {
    object Idle : PomodoroState()
    object FocusRunning : PomodoroState()
    object BreakRunning : PomodoroState()
    object Paused : PomodoroState()
}

data class PomodoroUiState(
    val state: PomodoroState = PomodoroState.Idle,
    val currentCycle: Int = 1,
    val totalCycles: Int = 4,
    val totalFocusTimeSec: Long = 0L,
    val remainingSeconds: Long = 25 * 60L,
    val targetDurationSec: Long = 25 * 60L,
    val isFocusPhase: Boolean = true,
    val focusDurationMin: Int = 25,
    val shortBreakMin: Int = 5,
    val longBreakMin: Int = 15,
    val completedSessionsToday: Int = 0
)

class PomodoroViewModel(
    private val sessionDao: StudySessionDao
) : ViewModel() {

    private val _uiState = MutableStateFlow(PomodoroUiState())
    val uiState: StateFlow<PomodoroUiState> = _uiState.asStateFlow()

    private var timerJob: Job? = null

    // Background persistence timestamps: survives orientation changes and onPause
    private var sessionStartTimestamp: Long = 0L
    private var allocatedDurationMs: Long = 25 * 60 * 1000L
    private var pausedRemainingMs: Long = 25 * 60 * 1000L

    fun startFocus() {
        val durationMs = _uiState.value.focusDurationMin * 60 * 1000L
        sessionStartTimestamp = System.currentTimeMillis()
        allocatedDurationMs = durationMs
        pausedRemainingMs = durationMs

        StudyNotificationListener.isFocusModeActive = true

        _uiState.update {
            it.copy(
                state = PomodoroState.FocusRunning,
                isFocusPhase = true,
                targetDurationSec = durationMs / 1000L,
                remainingSeconds = durationMs / 1000L
            )
        }
        startTicker()
    }

    fun pauseTimer() {
        timerJob?.cancel()
        val elapsedMs = System.currentTimeMillis() - sessionStartTimestamp
        pausedRemainingMs = (allocatedDurationMs - elapsedMs).coerceAtLeast(0L)

        _uiState.update { it.copy(state = PomodoroState.Paused) }
    }

    fun resumeTimer() {
        sessionStartTimestamp = System.currentTimeMillis()
        allocatedDurationMs = pausedRemainingMs

        val nextState = if (_uiState.value.isFocusPhase) PomodoroState.FocusRunning else PomodoroState.BreakRunning
        _uiState.update { it.copy(state = nextState) }
        startTicker()
    }

    fun resetTimer() {
        timerJob?.cancel()
        StudyNotificationListener.isFocusModeActive = false
        val defaultSec = _uiState.value.focusDurationMin * 60L
        pausedRemainingMs = defaultSec * 1000L

        _uiState.update {
            it.copy(
                state = PomodoroState.Idle,
                isFocusPhase = true,
                remainingSeconds = defaultSec,
                targetDurationSec = defaultSec
            )
        }
    }

    fun syncFromBackgroundResume() {
        // Called when MainActivity resumes from background
        if (_uiState.value.state == PomodoroState.FocusRunning || _uiState.value.state == PomodoroState.BreakRunning) {
            val elapsedMs = System.currentTimeMillis() - sessionStartTimestamp
            val remaining = (allocatedDurationMs - elapsedMs).coerceAtLeast(0L) / 1000L
            if (remaining <= 0L) {
                onCycleComplete()
            } else {
                _uiState.update { it.copy(remainingSeconds = remaining) }
            }
        }
    }

    private fun startTicker() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (true) {
                delay(1000L)
                val elapsedMs = System.currentTimeMillis() - sessionStartTimestamp
                val remainingSec = (allocatedDurationMs - elapsedMs).coerceAtLeast(0L) / 1000L

                _uiState.update {
                    it.copy(
                        remainingSeconds = remainingSec,
                        totalFocusTimeSec = if (it.isFocusPhase) it.totalFocusTimeSec + 1 else it.totalFocusTimeSec
                    )
                }

                if (remainingSec <= 0L) {
                    onCycleComplete()
                    break
                }
            }
        }
    }

    private fun onCycleComplete() {
        timerJob?.cancel()
        val wasFocus = _uiState.value.isFocusPhase

        if (wasFocus) {
            // Log study session in local Room database
            viewModelScope.launch {
                sessionDao.insertSession(
                    StudySessionEntity(
                        timestamp = System.currentTimeMillis(),
                        durationMinutes = _uiState.value.focusDurationMin,
                        completedSuccessfully = true
                    )
                )
            }
        }

        val nextCycle = if (wasFocus) _uiState.value.currentCycle else _uiState.value.currentCycle + 1
        val isLongBreak = nextCycle % _uiState.value.totalCycles == 0
        val breakMinutes = if (isLongBreak) _uiState.value.longBreakMin else _uiState.value.shortBreakMin
        val nextDurationMs = breakMinutes * 60 * 1000L

        sessionStartTimestamp = System.currentTimeMillis()
        allocatedDurationMs = nextDurationMs
        pausedRemainingMs = nextDurationMs

        StudyNotificationListener.isFocusModeActive = !wasFocus

        _uiState.update {
            it.copy(
                state = if (wasFocus) PomodoroState.BreakRunning else PomodoroState.Idle,
                isFocusPhase = !wasFocus,
                currentCycle = nextCycle,
                completedSessionsToday = if (wasFocus) it.completedSessionsToday + 1 else it.completedSessionsToday,
                remainingSeconds = nextDurationMs / 1000L,
                targetDurationSec = nextDurationMs / 1000L
            )
        }

        if (wasFocus) {
            startTicker()
        }
    }
}