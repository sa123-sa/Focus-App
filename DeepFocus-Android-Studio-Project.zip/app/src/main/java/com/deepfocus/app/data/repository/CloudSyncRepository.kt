package com.deepfocus.app.data.repository

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import com.deepfocus.app.data.local.dao.FlashcardDao
import com.deepfocus.app.data.local.dao.NoteDao
import com.deepfocus.app.data.local.entity.FlashcardEntity
import com.deepfocus.app.data.local.entity.NoteEntity
import com.deepfocus.app.data.remote.TelegramApiService
import com.deepfocus.app.data.remote.model.TelegramMessageRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class CloudSyncRepository(
    private val context: Context,
    private val telegramApi: TelegramApiService,
    private val flashcardDao: FlashcardDao,
    private val noteDao: NoteDao
) {

    /**
     * SYNC WITH TELEGRAM BOT API:
     * Pushes study notes and flashcards formatted in Markdown to private Telegram group
     */
    suspend fun syncNotesToTelegram(botToken: String, chatId: String): Result<Int> = withContext(Dispatchers.IO) {
        try {
            val pendingNotes = noteDao.getUnsyncedNotes()
            var syncedCount = 0

            for (note in pendingNotes) {
                val markdown = buildString {
                    appendLine("📚 *[DeepFocus Study Note]*")
                    appendLine("*Topic:* ${note.title}")
                    appendLine("*Timestamp:* ${note.formattedDate}")
                    appendLine("---")
                    appendLine(note.content)
                }

                val response = telegramApi.sendMessage(
                    botToken = "bot$botToken",
                    request = TelegramMessageRequest(
                        chatId = chatId,
                        text = markdown,
                        parseMode = "Markdown"
                    )
                )

                if (response.isSuccessful && response.body()?.ok == true) {
                    noteDao.markAsSynced(note.id)
                    syncedCount++
                }
            }

            Result.success(syncedCount)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * HEAVY 500MB PDF DOWNLOAD VIA ANDROID DownloadManager:
     * Offloads download to OS daemon with network resumption and private app storage
     */
    fun enqueueGoogleDrivePdf(googleDriveUrl: String, fileName: String): Long {
        val downloadUri = Uri.parse(googleDriveUrl)

        // Target storage in app-specific private directory:
        // /storage/emulated/0/Android/data/com.deepfocus.app/files/Documents/
        val destinationDir = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS)
        val destinationFile = File(destinationDir, fileName)

        val request = DownloadManager.Request(downloadUri).apply {
            setTitle("Downloading Textbook: $fileName")
            setDescription("DeepFocus Heavy PDF Sync (Up to 500MB)")
            setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            setDestinationUri(Uri.fromFile(destinationFile))
            // Support downloading across Wi-Fi and Cellular
            setAllowedNetworkTypes(
                DownloadManager.Request.NETWORK_WIFI or DownloadManager.Request.NETWORK_MOBILE
            )
            setAllowedOverMetered(true)
            setAllowedOverRoaming(false)
        }

        val downloadManager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        return downloadManager.enqueue(request)
    }

    /**
     * Query DownloadManager status for real-time progress & error diagnostics
     */
    fun queryDownloadProgress(downloadId: Long): Triple<Int, Long, Long> {
        val downloadManager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val query = DownloadManager.Query().setFilterById(downloadId)
        val cursor = downloadManager.query(query)

        cursor?.use {
            if (it.moveToFirst()) {
                val bytesDownloadedIndex = it.getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)
                val bytesTotalIndex = it.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
                val statusIndex = it.getColumnIndex(DownloadManager.COLUMN_STATUS)

                val downloaded = if (bytesDownloadedIndex != -1) it.getLong(bytesDownloadedIndex) else 0L
                val total = if (bytesTotalIndex != -1) it.getLong(bytesTotalIndex) else 0L
                val status = if (statusIndex != -1) it.getInt(statusIndex) else DownloadManager.STATUS_FAILED

                return Triple(status, downloaded, total)
            }
        }
        return Triple(DownloadManager.STATUS_FAILED, 0L, 0L)
    }
}