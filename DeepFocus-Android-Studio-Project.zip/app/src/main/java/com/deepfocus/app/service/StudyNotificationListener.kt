package com.deepfocus.app.service

import android.app.Notification
import android.content.Context
import android.os.Build
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.telephony.TelephonyManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch

data class InterceptedNotification(
    val id: String,
    val packageName: String,
    val title: String,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isEmergencyCall: Boolean = false,
    val isVoipCall: Boolean = false
)

class StudyNotificationListener : NotificationListenerService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    companion object {
        private val _interceptedFlow = MutableSharedFlow<InterceptedNotification>(replay = 0, extraBufferCapacity = 64)
        val interceptedFlow = _interceptedFlow.asSharedFlow()

        // Global flag controlled by PomodoroViewModel
        @Volatile
        var isFocusModeActive: Boolean = false

        // Packages that should be suppressed during deep study
        private val DISTRACTING_PACKAGES = setOf(
            "com.whatsapp",
            "org.telegram.messenger",
            "com.instagram.android",
            "com.twitter.android",
            "com.facebook.katana",
            "com.facebook.orca",
            "com.google.android.gm",
            "com.slack",
            "com.discord",
            "com.tiktok.android"
        )
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        sbn ?: return

        val packageName = sbn.packageName
        val notification = sbn.notification ?: return
        val extras = notification.extras

        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        val category = notification.category

        // 1. EMERGENCY CALL DETECTION: Cellular & VoIP Pass-Through
        val isCallCategory = category == Notification.CATEGORY_CALL ||
                category == Notification.CATEGORY_MISSED_CALL
        val isIncomingCall = isCallCategory ||
                (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                        notification.isStyle(Notification.CallStyle::class.java))

        // Check if Telephony is ringing for standard cellular calls
        val telephonyManager = getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
        @Suppress("DEPRECATION")
        val isCellularRinging = telephonyManager?.callState == TelephonyManager.CALL_STATE_RINGING

        if (isIncomingCall || isCellularRinging) {
            // NEVER suppress cellular or VoIP calls. Allow audible ringing & full system alert.
            serviceScope.launch {
                _interceptedFlow.emit(
                    InterceptedNotification(
                        id = "${sbn.id}_${sbn.postTime}",
                        packageName = packageName,
                        title = if (title.isNotBlank()) title else "Incoming Call",
                        text = if (text.isNotBlank()) text else "Emergency / VoIP Call Ringing",
                        isEmergencyCall = true,
                        isVoip = !isCellularRinging
                    )
                )
            }
            return
        }

        // 2. FOCUS MODE MUTE: Suppress social & messaging alerts
        if (isFocusModeActive) {
            val isSocialOrDistracting = packageName in DISTRACTING_PACKAGES ||
                    category in listOf(
                        Notification.CATEGORY_MESSAGE,
                        Notification.CATEGORY_SOCIAL,
                        Notification.CATEGORY_EMAIL,
                        Notification.CATEGORY_PROMO
                    )

            if (isSocialOrDistracting) {
                // Cancel notification sound/vibration or dismiss from status bar if active
                try {
                    // Suppress notification interruption
                    cancelNotification(sbn.key)
                } catch (e: Exception) {
                    // Silently ignore if permission is restricted
                }

                // Forward to in-app non-intrusive heads-up banner so user never misses critical info
                serviceScope.launch {
                    _interceptedFlow.emit(
                        InterceptedNotification(
                            id = "${sbn.id}_${sbn.postTime}",
                            packageName = packageName,
                            title = title,
                            text = text,
                            isEmergencyCall = false,
                            isVoip = false
                        )
                    )
                }
            }
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        super.onNotificationRemoved(sbn)
    }
}