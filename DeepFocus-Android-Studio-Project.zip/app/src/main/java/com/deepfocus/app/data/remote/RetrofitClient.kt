package com.deepfocus.app.data.remote

import com.deepfocus.app.data.remote.model.TelegramMessageRequest
import com.deepfocus.app.data.remote.model.TelegramResponse
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Path
import java.util.concurrent.TimeUnit

interface TelegramApiService {
    @POST("{botToken}/sendMessage")
    suspend fun sendMessage(
        @Path("botToken") botToken: String,
        @Body request: TelegramMessageRequest
    ): Response<TelegramResponse>
}

object RetrofitClient {

    private const val TELEGRAM_BASE_URL = "https://api.telegram.org/"

    private val okHttpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .addInterceptor(HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.BODY
            })
            .addInterceptor { chain ->
                val request = chain.request().newBuilder()
                    .header("User-Agent", "DeepFocus-Android-StudyEngine/1.0")
                    .header("Content-Type", "application/json")
                    .build()
                chain.proceed(request)
            }
            .build()
    }

    val telegramApi: TelegramApiService by lazy {
        Retrofit.Builder()
            .baseUrl(TELEGRAM_BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(TelegramApiService::class.java)
    }
}