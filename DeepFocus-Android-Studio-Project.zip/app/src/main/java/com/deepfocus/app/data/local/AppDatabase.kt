package com.deepfocus.app.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.deepfocus.app.data.local.dao.FlashcardDao
import com.deepfocus.app.data.local.dao.NoteDao
import com.deepfocus.app.data.local.dao.StudySessionDao
import com.deepfocus.app.data.local.entity.FlashcardEntity
import com.deepfocus.app.data.local.entity.NoteEntity
import com.deepfocus.app.data.local.entity.StudySessionEntity

@Database(
    entities = [
        StudySessionEntity::class,
        FlashcardEntity::class,
        NoteEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun studySessionDao(): StudySessionDao
    abstract fun flashcardDao(): FlashcardDao
    abstract fun noteDao(): NoteDao
}